#! /usr/bin/perl

# ------------------------------------------
# Script written by Anil Jagtap (c) 2015
# Email: anil.softx@gmail.com
# Published under GNU GPL
# V 0.2 (Stable)
# ------------------------------------------
use Term::ANSIColor;
use HTTP::Request::Common qw(POST);
use LWP::UserAgent;

my $ua = LWP::UserAgent->new;
$ua->timeout(5); #Wait maximum 5 seconds to get the result

$range = $ARGV[0];
$start = $ARGV[1];
$bit = ($start > 0)?$start:0;

$SIG{INT} = sub { print color 'reset';exit };

while ( $bit <= 255 ){
 $host = "$range.$bit";
 testRT($host);
 $bit++;
}

sub testRT{
  my $host = shift; 
  print "Checking $host ..";

  my $req = POST "http://$host",
               Content_Type => form-data,
               Content => [
                           username=>'admin',
			   password=>'admin'
                          ];
  $req->authorization_basic('admin', 'admin');

  my $content = $ua->request($req)->as_string;
 
  if( length($content) > 0 ){
     print color 'green';
     print ".\n";
  }else{
     print color 'red';
     print ".\n";
  }
  print color 'reset';

  if ( $content =~ /OK/ ){
    print "\t\tGoat $host ";
      if ( $content =~ /CPPLUS/ ){
         print " CPPLUS Camera";
      }
      if ( $content =~ /NETSuveillance/ ){
	print " Unknown camera";
      }
      if ( $content =~ /DNVRS-Webs/ ){
	print " DNVRS-Webs camera";
      }
      if ( $content =~ /WEB SERVICE/ ){
	print " Unknown Web Service camera";
      }
      if ( $content =~ /Content-Length: 536/ ){
	print "Boring DLink 520T Modem";
      }
      if ( $content =~ /DVR Components Download/ ){
	print "Stupid downloader";
      }
    print "\n";
  }
}

